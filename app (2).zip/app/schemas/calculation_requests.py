from pydantic import BaseModel, Field, model_validator
from typing import Optional, List
from datetime import datetime
from enum import Enum


class RequestChannel(str, Enum):
    WEB_APP       = "web_app"
    ADMIN_CONSOLE = "admin_console"
    SALES_CONSOLE = "sales_console"
    VOICE_AGENT   = "voice_agent"
    CHAT_FORM     = "chat_form"


class EventType(str, Enum):
    WEDDING          = "wedding"
    CORPORATE_LUNCH  = "corporate_lunch"
    BIRTHDAY         = "birthday"
    SOCIAL_GATHERING = "social_gathering"


class ServiceStyle(str, Enum):
    BUFFET     = "buffet"
    PLATED     = "plated"
    BOXED_MEAL = "boxed_meal"


class RequestStatus(str, Enum):
    PENDING    = "pending"
    PROCESSING = "processing"
    COMPLETED  = "completed"
    FAILED     = "failed"


# ── Sub-schemas ───────────────────────────────────────────────────────────────

class EventDetails(BaseModel):
    eventName:    str          = Field(..., min_length=1)   # mandatory
    eventType:    EventType
    eventDate:    datetime                                  # mandatory
    serviceStyle: ServiceStyle
    venue:        Optional[str] = None                      # optional


class GuestDetailsInput(BaseModel):
    """User-facing input — only adultCount and kidsCount. totalGuests is never asked."""
    adultCount: int = Field(..., ge=0)
    kidsCount:  int = Field(default=0, ge=0)


class GuestDetailsStored(GuestDetailsInput):
    """Stored in DB — totalGuests auto-computed before insert."""
    totalGuests: int = Field(default=0, ge=0)

    @model_validator(mode="after")
    def compute_total(self):
        self.totalGuests = self.adultCount + self.kidsCount
        return self


class MenuItem(BaseModel):
    itemCode:  str
    category:  str
    vegNonVeg: str = Field(..., pattern="^(Veg|Non Veg)$")


class SpecialFlags(BaseModel):
    vipEvent:     bool          = False
    outdoorEvent: bool          = False
    customNote:   Optional[str] = None


# ── Request / Response models ─────────────────────────────────────────────────

class CalculationRequestCreate(BaseModel):
    """
    Payload accepted from any channel.
    Fields injected by backend (never trusted from payload):
      requestId, ruleVersionId, requestedBy, status, normalizedAt, createdAt, bufferPercent
    """
    # restaurantId → sourced from RESTAURANT_ID constant
    requestChannel: RequestChannel
    eventDetails:   EventDetails
    guestDetails:   GuestDetailsInput       # user sends only adultCount + kidsCount
    menuItems:      List[MenuItem] = Field(..., min_length=1)
    bufferPercent:  Optional[float] = Field(default=8, ge=0, le=100)#defaul=8 given like db percentage
    specialFlags:   SpecialFlags = Field(default_factory=SpecialFlags)


class CalculationRequestResponse(BaseModel):
    id:             Optional[str]       = Field(None, alias="_id")
    requestId:      str
    restaurantId:   str
    requestChannel: RequestChannel
    eventDetails:   EventDetails
    guestDetails:   GuestDetailsStored  # response shows totalGuests too
    menuItems:      List[MenuItem]
    bufferPercent:  Optional[float]
    specialFlags:   SpecialFlags
    ruleVersionId:  str
    requestedBy:    str
    status:         RequestStatus       = RequestStatus.PENDING
    normalizedAt:   Optional[datetime]  = None
    createdAt:      Optional[datetime]  = None

    class Config:
        populate_by_name = True


class CalculationRequestStatusUpdate(BaseModel):
    """Internal — used by the engine to advance status only."""
    status:       RequestStatus
    normalizedAt: Optional[datetime] = None