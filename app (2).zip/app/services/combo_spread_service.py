from datetime import datetime, timezone
from app.core.database import get_db
from app.core.constants import RESTAURANT_ID
from app.utils.excel_parser import parse_combo_spread

COLLECTION = "menu_item_rules"


async def update_combo_spread(
    version_id: str,
    combo_file_path: str,
    uploaded_by: str
) -> dict:
    """
    Upload and update combo spread rules separately.
    Can be called independently after main import.
    Replaces existing combo spread for the restaurant.
    """
    db = get_db()
    now = datetime.now(timezone.utc)

    # Parse combo file
    combo_rules = parse_combo_spread(combo_file_path)

    # Check if combo spread already exists
    existing = await db[COLLECTION].find_one({
        "restaurantId": RESTAURANT_ID,
        "itemCode": "COMBO_SPREAD_APPETIZER"
    })

    combo_doc = {
        "restaurantId": RESTAURANT_ID,
        "ruleVersionId": version_id,
        "itemCode": "COMBO_SPREAD_APPETIZER",
        "menuName": "Combo Spread Rules",
        "category": "Appetizer",
        "style": "All",
        "vegNonVeg": "Veg",
        "sellByCount": False,
        "adjustmentPct": 0,
        "adjustmentMultiplier": 1.0,
        "roundingRule": "full_tray",
        "scenarios": None,
        "countScenarios": None,
        "comboSpreadRules": combo_rules,
        "isActive": True,
        "source": "excel",
        "updatedAt": now,
        "updatedBy": uploaded_by,
    }

    if existing:
        # Update existing combo spread
        await db[COLLECTION].update_one(
            {
                "restaurantId": RESTAURANT_ID,
                "itemCode": "COMBO_SPREAD_APPETIZER"
            },
            {"$set": combo_doc}
        )
        action = "updated"
    else:
        # Create new combo spread
        combo_doc["createdAt"] = now
        await db[COLLECTION].insert_one(combo_doc)
        action = "created"

    return {
        "success": True,
        "action": action,
        "comboKeys": [c["comboKey"] for c in combo_rules["combos"]],
        "totalCombos": len(combo_rules["combos"]),
        "updatedAt": now.isoformat()
    }


async def get_combo_spread() -> dict:
    """Get current combo spread rules for a restaurant"""
    db = get_db()
    doc = await db[COLLECTION].find_one({
        "restaurantId": RESTAURANT_ID,
        "itemCode": "COMBO_SPREAD_APPETIZER",
        "isActive": True
    })
    if doc:
        doc["_id"] = str(doc["_id"])
    return doc


async def clear_combo_spread_rules(version_id: str) -> int:
    """
    Clears combo spread data from menu_item_rules collection.
    """
    db = get_db()

    result = await db.menu_item_rules.delete_many(  # ✅ delete_many instead of update_many
        {
            "restaurantId": RESTAURANT_ID,
            "ruleVersionId": version_id
        }
    )

    print(f"Combo spreads cleared: {result.deleted_count}")
    return result.deleted_count  # ✅ deleted_count instead of modified_count