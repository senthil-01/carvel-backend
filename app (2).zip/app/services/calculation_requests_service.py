from datetime import datetime, timezone
from typing import Optional
import uuid

from app.core.database import get_db
from app.core.constants import RESTAURANT_ID
from app.schemas.calculation_requests import (
    CalculationRequestCreate,
    CalculationRequestStatusUpdate,
    RequestStatus,
    GuestDetailsStored,
)

COLLECTION = "calculation_requests"


def _serialize(doc) -> dict:
    if doc and "_id" in doc:
        doc["_id"] = str(doc["_id"])
    return doc


# ── Internal helpers ──────────────────────────────────────────────────────────

async def _get_active_rule_version_id() -> str:
    db = get_db()
    doc = await db["rule_versions"].find_one(
        {"restaurantId": RESTAURANT_ID, "status": "active"},
        {"versionId": 1}
    )
    if not doc:
        raise ValueError(
            f"No active rule version found for restaurant '{RESTAURANT_ID}'. "
            "Publish a rule version before submitting requests."
        )
    return doc["versionId"]


async def _get_default_buffer() -> float:
    """Fetch default buffer% from rule_multipliers (type: buffer). Falls back to 8 if not configured."""
    db = get_db()
    doc = await db["rule_multipliers"].find_one(
        {"restaurantId": RESTAURANT_ID, "multiplierType": "buffer", "isActive": True},
        {"bufferPercent": 1}
    )
    return float(doc["bufferPercent"]) if doc else 8.0


# ── Service functions ─────────────────────────────────────────────────────────

async def create_calculation_request(
    data: CalculationRequestCreate,
    requested_by: str
) -> dict:
    db = get_db()
    now = datetime.now(timezone.utc)

    # Auto-stamp active ruleVersionId
    rule_version_id = await _get_active_rule_version_id()

    # User value takes priority — else fetch default from rule_multipliers and store it
    buffer_percent = data.bufferPercent if data.bufferPercent is not None else await _get_default_buffer()

    request_id = f"REQ-{uuid.uuid4().hex[:12].upper()}"

    doc = data.model_dump(exclude_none=False)
    doc["restaurantId"]   = RESTAURANT_ID
    doc["requestId"]      = request_id
    doc["ruleVersionId"]  = rule_version_id
    doc["requestedBy"]    = requested_by
    doc["bufferPercent"]  = buffer_percent
    doc["status"]         = RequestStatus.PENDING.value
    doc["normalizedAt"]   = None
    doc["createdAt"]      = now

    # Serialize enums inside nested objects
    doc["requestChannel"]               = data.requestChannel.value
    doc["eventDetails"]["eventType"]    = data.eventDetails.eventType.value
    doc["eventDetails"]["serviceStyle"] = data.eventDetails.serviceStyle.value

    doc["guestDetails"] = GuestDetailsStored(**data.guestDetails.model_dump()).model_dump()

    result = await db[COLLECTION].insert_one(doc)
    doc["_id"] = str(result.inserted_id)
    return doc


async def get_request_by_id(request_id: str) -> Optional[dict]:
    db = get_db()
    doc = await db[COLLECTION].find_one({
        "restaurantId": RESTAURANT_ID,
        "requestId": request_id
    })
    return _serialize(doc) if doc else None


async def get_all_requests(
    status: Optional[str] = None,
    event_type: Optional[str] = None,
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
    page: int = 1,
    page_size: int = 20
) -> dict:
    db = get_db()
    query: dict = {"restaurantId": RESTAURANT_ID}

    if status:
        query["status"] = status
    if event_type:
        query["eventDetails.eventType"] = event_type

    date_filter: dict = {}
    if from_date:
        date_filter["$gte"] = from_date
    if to_date:
        date_filter["$lte"] = to_date
    if date_filter:
        query["eventDetails.eventDate"] = date_filter

    skip = (page - 1) * page_size
    total = await db[COLLECTION].count_documents(query)

    cursor = db[COLLECTION].find(query).sort("createdAt", -1).skip(skip).limit(page_size)
    results = []
    async for doc in cursor:
        results.append(_serialize(doc))

    return {"total": total, "page": page, "page_size": page_size, "results": results}


async def update_request_status(
    request_id: str,
    data: CalculationRequestStatusUpdate
) -> Optional[dict]:
    db = get_db()

    existing = await db[COLLECTION].find_one(
        {"restaurantId": RESTAURANT_ID, "requestId": request_id},
        {"status": 1}
    )
    if not existing:
        return None

    # Enforce valid state machine transitions
    allowed_transitions = {
        RequestStatus.PENDING.value:    {RequestStatus.PROCESSING.value},
        RequestStatus.PROCESSING.value: {RequestStatus.COMPLETED.value, RequestStatus.FAILED.value},
    }
    if data.status.value not in allowed_transitions.get(existing["status"], set()):
        raise ValueError(
            f"Invalid transition: '{existing['status']}' → '{data.status.value}'"
        )

    update_fields: dict = {"status": data.status.value}
    if data.normalizedAt:
        update_fields["normalizedAt"] = data.normalizedAt

    result = await db[COLLECTION].find_one_and_update(
        {"restaurantId": RESTAURANT_ID, "requestId": request_id},
        {"$set": update_fields},
        return_document=True
    )
    return _serialize(result) if result else None


async def get_pending_queue() -> list:
    """FIFO queue — oldest pending first. Used by the calculation engine worker."""
    db = get_db()
    cursor = db[COLLECTION].find({
        "restaurantId": RESTAURANT_ID,
        "status": RequestStatus.PENDING.value
    }).sort("createdAt", 1)

    results = []
    async for doc in cursor:
        results.append(_serialize(doc))
    return results


async def create_indexes():
    db = get_db()

    # { restaurantId, createdAt: -1 } — recent request history
    await db[COLLECTION].create_index(
        [("restaurantId", 1), ("createdAt", -1)],
        name="idx_restaurantId_createdAt_desc"
    )
    # { requestId } unique — referenced by calculation_results
    await db[COLLECTION].create_index(
        [("requestId", 1)],
        unique=True,
        name="idx_requestId_unique"
    )
    # { restaurantId, status } — pending / failed request management
    await db[COLLECTION].create_index(
        [("restaurantId", 1), ("status", 1)],
        name="idx_restaurantId_status"
    )
    # { eventDetails.eventDate } — date-based filtering and reporting
    await db[COLLECTION].create_index(
        [("eventDetails.eventDate", 1)],
        name="idx_eventDetails_eventDate"
    )
    print(f"Indexes created for {COLLECTION}")